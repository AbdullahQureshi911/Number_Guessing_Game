import random

# Choose a random number between 1 and 10
secret_number = random.randint(1, 10)

# Ask user how many attempts they want
attempts = int(input("How many attempts do you need to clear this? "))
print("Guess the number between 1 and 10")

for i in range(1, attempts + 1):
    guess = int(input(f"Attempt {i}: Enter your guess: "))

    if guess == secret_number:
        print("🎉 Your number is correct!")

        # Points system based on attempt number
        if i == 1:
            print("You earned 10 points!")
        elif i == 2:
            print("You earned 8 points!")
        elif i == 3:
            print("You earned 6 points!")
        elif i == 4:
            print("You earned 4 points!")
        elif i == 5:
            print("You earned 2 points!")
        else:
            print("You earned 1 point!")

        break  # End the game if guessed correctly

    elif guess > secret_number:
        print("Too high! Try again.")
    elif guess < secret_number:
        print("Too low! Try again.")

    if i == attempts:
        print("\n❌ You've used all your attempts. Better luck next time!")
        print(f"The correct number was: {secret_number}")
        print("You earned 0 points.")